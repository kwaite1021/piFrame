/* ========================================
 *
 * Written by Kevin Waite
 * Last Update 25OCT2017
 * Note on ADC: The ADC is triggered by the rising edge of the
 * SS Line and gives one conversion per trigger - does not run
 * continously. It returns 11 bits as we are using signed format, , negative
 * rail to VDD.
 * ============ PSOC 4 SLAVE ==============
 *
    Master: |MasterDataMSB|  |MasterDataByte3| |MasterDataByte2|   |MasterDataByte1|   |MasterDataLSB|
    Slave:  |JunkByte|       |SlaveDataMSB|   |SlaveDataByte2|    |SlaveDataByte1|    |SlaveDataLSB|

*/

#include "project.h"
#include <stdio.h>
///* ADC SAR sequencer component header to access Vref value */
//#include <ADC.h>
//
//#define CH0_N               (0x00u)
//#define TEMP_CH             (0x01u)
//#define DELAY_1SEC          (1000u)
//
///* Get actual Vref. value from ADC SAR sequencer */
//#define ADC_VREF_VALUE_V    ((float)ADC_DEFAULT_VREF_MV_VALUE/1000.0)

volatile uint32 dataReady = 0u;
volatile int16 result[ADC_TOTAL_CHANNELS_NUM];
uint16_t AdcVAL = 0;


void LoadTX(uint8 byte1,uint8 byte2,uint8 byte3,uint8 byte4){
    // Clear buffers and FIFO's  
    SPIS_ClearRxBuffer();
    SPIS_ClearTxBuffer();
    SPIS_ClearFIFO();
    //pre-load the TX buffer for next bus transmission
    uint8_t TxARR[] = {byte1,byte2,byte3,byte4};
    //We send 4 bytes in response to 4 byte clock cycles from Master
    //The first byte sent "SPIS_WriteTxDataZero" is only used because 
    //the SPI is operating in mode 0,0.
    //Load the junk byte into the shift register
    SPIS_WriteTxDataZero(0x0);
    //Place the data in the TX buffer for next transmission
    SPIS_PutArray(TxARR,4);
    
     
}

void ClearSPI(){
    // Clear buffers and FIFO's  
    SPIS_ClearRxBuffer();
    SPIS_ClearTxBuffer();
    SPIS_ClearFIFO();
  }


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    Opamp_1_Start();
    //Enable & start the ADC
    ADC_Start();
    ADC_IRQ_Enable();
    //Enable & start the SPI
    SPIS_Start();
    //Enable UART
    //UART_Start();    
    uint8_t Mcommand = 0;
    uint8_t MasterDataMSB = 0;
    uint8_t MasterDataByte2 = 0;
    uint8_t MasterDataByte1 = 0;
    uint8_t MasterDataLSB = 0;    
    uint8_t SlaveDataMSB = 0;
    uint8_t SlaveDataByte2 = 0;
    uint8_t SlaveDataByte1 = 0;
    uint8_t SlaveDataLSB = 0;
    uint16_t SlaveAdd = 0;
    uint16_t MyADC = 0;
    char TestSTR [20];
    //pre-load TX register
    ClearSPI();
    LoadTX(SlaveDataMSB,SlaveDataByte2,SlaveDataByte1,SlaveDataLSB);  
    
    for(;;)
    {
   
    //SPI busy transmitting
    while(!(SPIS_ReadTxStatus() | SPIS_STS_SPI_DONE)){
        
    }  
    if(SPIS_ReadRxStatus() | SPIS_STS_RX_BUF_NOT_EMPTY){
        Mcommand = SPIS_ReadRxData();   
        MasterDataMSB = SPIS_ReadRxData();
        MasterDataByte2 = SPIS_ReadRxData();
        MasterDataByte1 = SPIS_ReadRxData(); 
        MasterDataLSB = SPIS_ReadRxData();
    }
              
    switch (Mcommand){
        case 0x0A:  //ADC
            if (dataReady != 0){
                dataReady = 0;
                MyADC = AdcVAL;                 
//                sprintf(TestSTR,"ADC: %d\n",MyADC);
//                UART_UartPutString(TestSTR);
                SlaveDataMSB = 0x0A;
                SlaveDataByte2 = 0x0B;
                SlaveDataByte1 =  MyADC >> 8;
                SlaveDataLSB = MyADC & 0xFF;
                LoadTX(SlaveDataMSB,SlaveDataByte2,SlaveDataByte1,SlaveDataLSB);                
            }
            //Set Mcommand = 0 so we only execute this once per Master request
            Mcommand = 0;
        break;
        case 0x14: //Blank
           // ADC_StopConvert();
            Mcommand = 0;
        break;
        case 0x1E:
           // Add two numbers together and return the result
//            sprintf(TestSTR,"Mcommand: %d\n",Mcommand);
//            UART_UartPutString(TestSTR);
//            sprintf(TestSTR,"DataMSB: %d\n",MasterDataMSB);
//            UART_UartPutString(TestSTR);
//            sprintf(TestSTR,"DataLSB: %d\n",MasterDataLSB);
//            UART_UartPutString(TestSTR);
            SlaveAdd = MasterDataByte1  + MasterDataLSB;
            //Next transmission data
            SlaveDataMSB = 0x1E;
            SlaveDataByte2 = 0x1E;
            SlaveDataByte1 = SlaveAdd >> 8;
            SlaveDataLSB = SlaveAdd & 0xFF;            
//            sprintf(TestSTR,"SlaveADD: %d\n",SlaveAdd);
//            UART_UartPutString(TestSTR);                             
            LoadTX(SlaveDataMSB,SlaveDataByte2,SlaveDataByte1,SlaveDataLSB);
            Mcommand = 0;
        break;
        case 0x28:  
            Mcommand = 0;
        break;
            
        default: 
           
        break;    
       }
        
    }
}

/* [] END OF FILE */
